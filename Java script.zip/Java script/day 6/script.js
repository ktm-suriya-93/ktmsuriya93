// Function to add a contact
function addContact() {
    let name = document.getElementById("name").value;
    let phone = document.getElementById("phone").value;
    let email = document.getElementById("email").value;

    if (name === "" || phone === "" || email === "") {
        alert("Please fill out all fields.");
        return;
    }

    let contactList = document.getElementById("contact-list");

    let li = document.createElement("li");
    li.innerHTML = `
        <strong>${name}</strong> <br> 
        ${phone} <br> 
        ${email} 
        <button onclick="deleteContact(this)">Delete</button>
    `;

    contactList.appendChild(li);

    // Clear input fields after adding
    document.getElementById("name").value = "";
    document.getElementById("phone").value = "";
    document.getElementById("email").value = "";
}

// Function to delete a contact
function deleteContact(button) {
    let li = button.parentElement;
    li.remove();
}
