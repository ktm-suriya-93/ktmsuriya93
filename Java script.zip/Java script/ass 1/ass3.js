let principal = 600;
let time = 0.5;
let rate = 15;

let interest = (principal * rate * time )/100;

let totalAmount = principal + interest;

console.log("Interest: $" + interest);

console.log("Total Amount: $" + totalAmount);
