
function hours_to_minutes(hours) {
    return hours * 60;
}
console.log("1. Hours to Minutes (2 hours):", hours_to_minutes(2)); 


function minutes_to_hours(minutes) {
    return minutes / 60;
}
console.log("2. Minutes to Hours (120 minutes):", minutes_to_hours(120)); 


function sec_to_hours(seconds) {
    return seconds / 3600;
}
console.log("3. Seconds to Hours (3600 seconds):", sec_to_hours(3600)); 


function hours_to_sec(hours) {
    return hours * 3600;
}
console.log("4. Hours to Seconds (2 hours):", hours_to_sec(2)); 


function day_to_year(days) {
    return days / 365;
}
console.log("5. Days to Years (600 days):", day_to_year(600)); 


function year_to_day(years) {
    return years * 365;
}
console.log("6. Years to Days (2 years):", year_to_day(2)); 


function month_to_days(months) {
    return months * 30;
}
console.log("7. Months to Days (2 months):", month_to_days(2)); 


function days_to_month(days) {
    return days / 30;
}
console.log("8. Days to Months (60 days):", days_to_month(60)); 


function month_to_years(months) {
    return months / 12;
}
console.log("9. Months to Years (2 months):", month_to_years(2)); 


function years_to_month(years) {
    return years * 12;
}
console.log("10. Years to Months (2 years):", years_to_month(2));


