var a= 15768;
var b =34890;
console.log(a+b,("total number of seats"))