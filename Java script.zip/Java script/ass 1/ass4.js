let principal = 2500 ;
let rate = 6 ;
let year = 3 ;

function calculateSimpleInterest (principal, rate, year) {
 const simpleIntrest = (principal*rate*year)/100;
 const totalAmount = principal + simpleIntrest;
 return totalAmount;
}

const totalAmount= calculateSimpleInterest(principal,rate,year)

console.log(`suriya will have $${totalAmount} at the end of the years.`);

