let computers =  14589;
let tablet = 1234;
let chair = 876;
let totalExpancess =(computers+tablet+chair);
console.log("The School Spends: $" + totalExpancess);